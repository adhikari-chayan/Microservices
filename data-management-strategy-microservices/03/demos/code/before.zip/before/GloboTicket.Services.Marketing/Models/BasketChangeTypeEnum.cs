﻿namespace GloboTicket.Services.Marketing.Models
{
    public enum BasketChangeTypeEnum
    {
        Add,
        Remove
    }
}