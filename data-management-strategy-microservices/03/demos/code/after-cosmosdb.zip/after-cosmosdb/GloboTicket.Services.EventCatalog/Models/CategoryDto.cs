﻿using System;

namespace GloboTicket.Services.EventCatalog.Models
{
    public class CategoryDto
    {
        public Guid CategoryId { get; set; }
        public string Name { get; set; }
    }
}
