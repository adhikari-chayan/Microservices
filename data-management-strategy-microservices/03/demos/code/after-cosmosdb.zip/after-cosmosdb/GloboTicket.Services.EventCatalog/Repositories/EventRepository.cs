﻿using GloboTicket.Services.EventCatalog.DbContexts;
using GloboTicket.Services.EventCatalog.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GloboTicket.Services.EventCatalog.Repositories
{
    public class EventRepository: IEventRepository
    {
        private readonly EventCatalogCosmosDbContext _cosmosDbContext;

        public EventRepository(EventCatalogCosmosDbContext dbContext)
        {
            _cosmosDbContext = dbContext;
        }

        public async Task<IEnumerable<Event>> GetEvents(Guid categoryId)
        {
            return await _cosmosDbContext.Events
                //.Include(x => x.Category)
                .Where(x => (Guid.Parse(x.CategoryId) == categoryId || categoryId == Guid.Empty))
                //.Include(x => x.Venue)
                .ToListAsync();
        }

        public async Task<Event> GetEventById(Guid eventId)
        {
            return await _cosmosDbContext.Events
                //.Include(x => x.Category)
                //.Include(x => x.Venue)
                .Where(x => x.EventId == eventId).FirstOrDefaultAsync();
        }
    }
}
